corr <- function(threshold){
      
      obs <- numeric()
	  for(i in 1:332){
      name <- as.character(i)
      if (0<i && i<=9){
      infile <- paste("00",name,".csv",sep="")
      }
      else if (9<i && i<=99){
      infile <- paste("0",name,".csv",sep="")
      }
      else{
      infile <- paste(name,".csv",sep="")
      }
      data <- read.csv(infile , header = TRUE)
      
      good <-na.omit(data)
      attach(good)    
      y <- nrow(good)
      if (y > threshold){
      z <- cor(sulfate,nitrate)
      obs <- append(obs, z)
      }
}     
      obs
}
